/* popup.js */
(() => {
  "use strict";

  const TARGET_URL = "https://one.google.com/plans";
  const LABELS = {
    off: "disabled",
    "12m": "12 months",
    "6m_ss": "6 months (SS)",
    "6m": "6 months",
    "6m_2": "6 months (alt)"
  };

  const stateEl = document.getElementById("state");
  const stateText = document.getElementById("state-text");
  const group = document.getElementById("layers");
  const radios = Array.from(group.querySelectorAll('input[name="layer"]'));

  let pollId = null;
  let writeToken = 0;
  let currentSelectedLayer = "off";

  function paintState(st, hasTargetTab) {
    const layer = (st && st.layer) || currentSelectedLayer || "off";
    const mounted = !!(st && st.mounted) && layer !== "off";

    if (mounted) {
      stateEl.className = "ok";
      stateText.textContent =
        "Mounted: " + (LABELS[layer] || layer) + " — tap here to switch to one.google.com/plans";
    } else if (layer === "off" && hasTargetTab) {
      stateEl.className = "warn";
      stateText.textContent =
        "Injection is turned off — pick a layer above to mount on one.google.com/plans";
    } else if (hasTargetTab) {
      stateEl.className = "warn";
      stateText.textContent =
        "Tab found but not mounted yet — tap here to refresh one.google.com/plans";
    } else {
      stateEl.className = "warn";
      stateText.textContent =
        "No injection detected (tap here to open one.google.com/plans)";
    }
  }

  // Finds an open one.google.com tab even when the popup is opened as a full mobile tab
  function findTargetTab(cb) {
    try {
      chrome.tabs.query({ url: ["https://one.google.com/*"] }, (tabs) => {
        if (!chrome.runtime.lastError && tabs && tabs.length > 0) {
          // Prefer the active one if multiple exist, otherwise most recent
          const activeOne = tabs.find((t) => t.active) || tabs[tabs.length - 1];
          return cb(activeOne);
        }
        // Fallback: check active tab if URL permission was restricted
        chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
          const t = activeTabs && activeTabs[0];
          if (t && t.url && t.url.startsWith("chrome-extension://")) {
            return cb(null);
          }
          cb(t || null);
        });
      });
    } catch (e) {
      cb(null);
    }
  }

  function queryTab() {
    findTargetTab((t) => {
      if (!t || !t.id) return paintState(null, false);
      try {
        chrome.tabs.sendMessage(t.id, { type: "getState" }, (resp) => {
          if (chrome.runtime.lastError || !resp) {
            return paintState(null, true);
          }
          paintState(resp, true);
        });
      } catch (e) {
        paintState(null, false);
      }
    });
  }

  function syncRadios(layer) {
    const value = LABELS[layer] ? layer : "off";
    currentSelectedLayer = value;
    radios.forEach((el) => {
      const isChecked = el.value === value;
      el.checked = isChecked;
      const row = el.closest("label.row");
      if (row) row.classList.toggle("selected", isChecked);
    });
    return value;
  }

  function apply(layer) {
    const token = ++writeToken;
    const validLayer = syncRadios(layer);

    document.body.classList.add("busy");

    chrome.storage.local.set({ gapt_layer: validLayer }, () => {
      if (token !== writeToken) return;
      if (chrome.runtime.lastError) {
        stateEl.className = "err";
        stateText.textContent = "Could not save the layer (storage error)";
        document.body.classList.remove("busy");
        return;
      }

      findTargetTab((t) => {
        if (!t || !t.id) {
          document.body.classList.remove("busy");
          return paintState({ layer: validLayer, mounted: false }, false);
        }
        try {
          chrome.tabs.sendMessage(t.id, { type: "setLayer", layer: validLayer }, (resp) => {
            void chrome.runtime.lastError;
            document.body.classList.remove("busy");
            if (resp && resp.state) {
              paintState(resp.state, true);
            } else {
              setTimeout(queryTab, 120);
            }
          });
        } catch (e) {
          document.body.classList.remove("busy");
          queryTab();
        }
      });
    });
  }

  // Make the yellow/green #state banner functional when tapped:
  // Opens one.google.com/plans if not open, or switches to & refreshes it if already open.
  function handleStateAction() {
    findTargetTab((t) => {
      if (t && t.id) {
        chrome.tabs.sendMessage(t.id, { type: "getState" }, (resp) => {
          const isMounted = !chrome.runtime.lastError && resp && resp.mounted && resp.layer !== "off";
          if (!isMounted) {
            try { chrome.tabs.reload(t.id); } catch (e) {}
          }
          try { chrome.tabs.update(t.id, { active: true }); } catch (e) {}
        });
      } else {
        try {
          chrome.tabs.create({ url: TARGET_URL, active: true });
        } catch (e) {
          window.open(TARGET_URL, "_blank", "noopener");
        }
      }
    });
  }

  stateEl.addEventListener("click", handleStateAction);
  stateEl.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") {
      ev.preventDefault();
      handleStateAction();
    }
  });

  group.addEventListener("change", (ev) => {
    const el = ev.target;
    if (!el || el.name !== "layer") return;
    apply(el.value);
  });

  chrome.storage.local.get(["gapt_layer"], (r) => {
    syncRadios((r && r.gapt_layer) || "off");
    queryTab();
    setTimeout(queryTab, 500);
    pollId = setInterval(queryTab, 1500);
  });

  window.addEventListener("pagehide", () => {
    if (pollId) clearInterval(pollId);
    pollId = null;
  });
})();
