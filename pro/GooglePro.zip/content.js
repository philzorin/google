/* Xi · Google AI Pro Offer Injector — content script (isolated world: relays config, reports state) */
(() => {
  if (window.__GAPT_CONTENT) return;
  window.__GAPT_CONTENT = true;

  const VALID = ["off", "12m", "6m_ss", "6m", "6m_2"];
  const normalize = (v) => (VALID.indexOf(v) >= 0 ? v : "off");

  let currentLayer = "off";
  let lastState = { layer: "off", mounted: false };

  function push(layer) {
    const safe = normalize(layer);
    currentLayer = safe;
    try {
      document.documentElement.setAttribute("data-gapt-layer", safe);
    } catch (e) {}
    window.postMessage({ __gapt: 1, type: "cfg", layer: safe }, "*");
  }

  function loadAndPush() {
    try {
      chrome.storage.local.get(["gapt_layer"], (r) => {
        if (chrome.runtime.lastError) return push(currentLayer);
        const saved = r && r.gapt_layer ? normalize(r.gapt_layer) : "off";
        push(saved);
      });
    } catch (e) {
      push(currentLayer);
    }
  }

  // MAIN world reports state back
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (d && d.__gapt === 1 && d.type === "state" && d.state) {
      lastState = d.state;
    }
  });

  // popup: query state / hot-apply config changes
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || !msg.type) return false;

      if (msg.type === "getState") {
        window.postMessage({ __gapt: 1, type: "ping" }, "*");
        setTimeout(() => sendResponse(lastState), 80);
        return true;
      }

      if (msg.type === "setLayer") {
        const safe = normalize(msg.layer);
        push(safe);
        setTimeout(() => sendResponse({ ok: true, state: lastState }), 80);
        return true;
      }
      return false;
    });

    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "local" && ch && ch.gapt_layer) {
        push(ch.gapt_layer.newValue || "off");
      }
    });
  } catch (e) {}

  loadAndPush();
  setTimeout(() => push(currentLayer), 800);
  setTimeout(() => push(currentLayer), 2500);
})();
