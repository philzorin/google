/* Xi · Google AI Pro Offer Injector — MAIN world
 * Hijacks Play checkout requests inside one.google.com and swaps the subscription
 * product for the configured offer token.
 */
(() => {
  if (window.__GAPT_HOOKED) return;
  window.__GAPT_HOOKED = true;

  const PREFIX = "subs:com.google.android.apps.subscriptions.red:";

  const TOKENS = {
    "12m": "AVbCH/cspB8VdqKJ+ax/uPxUFAVuYRPX4iSjtg4Fu0PG9zUeURSM7y//LlQva1dCd/rbKVM6EJmyiG/C9BoQ95pMl8yDCHuiwCvM5CuGJME=",
    "6m_ss": "AVbCH/cgl4zvPT2Lqw95Gn+RYAJIVwFwi783i6uVprX7u3MCa5J4CcTXH5RABa5WjBrUoQnwf8vI10TNV7ktd26myIdxqIwGmNoJ5ofYNqpQ10RKoSvHs75wsfA=",
    "6m": "AVbCH/fUON3w8hpfeutprA3BMQwrBwYIB6Y8CSWi1isDCDswKUUhGQ3dluj5WXsNKOvr8K5UULBGrRsf4KlW1rHLz0fF3SvxQhBFRbBOHCA=",
    "6m_2": "AVbCH/cJ5SeHgkVRt+bdcrapx/aLSu2kbsBgMdI413zbllDNsNQoC/zVlG/Npbu55WlMzBwWPhUedIvZFDg7fw0CmCv/8DKj04IZ21pK7mrV/hh5"
  };
  const YT_FREE_TOK = "AVbCH/eW4Nfp8KBl0zlm7x9PhaiCvpnqwUuL2D8NFPBQgmM9+HuYS1h2xH5lLWU/BsBj775LK5GqK8UHKqoSzhDDz+PqP3paNesqLU0r9i6XCrYa";

  const LAYER_LABELS = {
    "12m": "12 months",
    "6m_ss": "6 months (SS)",
    "6m": "6 months",
    "6m_2": "6 months (alt)"
  };

  let currentTest = null;
  let subId = null;

  /* Clone so the shared config object is never mutated by callers. */
  function cloneItems() {
    return [
      [[PREFIX + "g1.2tb.ai.subs_variant", 21], null, null, null, 1, [TOKENS[currentTest.layer]]],
      [[PREFIX + "g1.youtube_premium_individual_add_on", 21], null, null, null, 1, [YT_FREE_TOK]]
    ];
  }

  function makeCfg(layer) {
    if (!layer || layer === "off" || !TOKENS[layer]) return null;
    return { name: "gapt_" + layer, ear8: null };
  }

  /* ---------- bottom-right status badge (Material Dark) ---------- */
  let badge = null;
  let badgeDot = null;
  let badgeText = null;

  const KIND_COLOR = { idle: "#8fa1af", active: "#00e2b8" };

  function ensureBadge() {
    if (badge || !document.body) return !!badge;
    badge = document.createElement("div");
    badge.setAttribute("role", "status");
    badge.setAttribute("aria-live", "polite");
    badge.style.cssText =
      "position:fixed;right:16px;bottom:16px;z-index:2147483647;pointer-events:none;" +
      "display:flex;align-items:center;gap:9px;padding:10px 14px;border-radius:14px;" +
      "font:12px/1.4 Roboto,'Segoe UI',system-ui,sans-serif;letter-spacing:.2px;color:#e6edf2;" +
      "background:rgba(19,27,33,.94);border:1px solid #2a3946;" +
      "box-shadow:0 4px 18px rgba(0,0,0,.45);backdrop-filter:blur(8px);max-width:280px;";

    badgeDot = document.createElement("span");
    badgeDot.style.cssText = "width:8px;height:8px;border-radius:50%;flex:0 0 auto;background:#8fa1af;";

    badgeText = document.createElement("span");
    badgeText.style.cssText = "flex:1;min-width:0;";

    badge.appendChild(badgeDot);
    badge.appendChild(badgeText);
    document.body.appendChild(badge);
    return true;
  }

  function showBadge(text, kind) {
    if (!ensureBadge()) return;
    badgeText.textContent = text;
    badgeDot.style.background = KIND_COLOR[kind] || KIND_COLOR.idle;
    badgeDot.style.boxShadow = kind === "active" ? "0 0 8px rgba(0,226,184,.85)" : "none";
  }

  function refreshBadge() {
    if (!currentTest) {
      showBadge("Injector: inactive", "idle");
      return;
    }
    const label = LAYER_LABELS[currentTest.layer] || currentTest.layer;
    showBadge("Injection mounted · " + label + (subId ? " · renewal stack" : ""), "active");
  }

  /* ---------- request rewriting ---------- */
  function patchNode(node) {
    if (!Array.isArray(node) || !currentTest) return false;
    let patched = false;

    if (node.length > 12 && Array.isArray(node[12])) {
      if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) {
        subId = node[7][5][0];
      }
      node[12] = cloneItems();
      const mode = (currentTest.ear8 && currentTest.ear8[1]) || 5;
      if (currentTest.ear8) {
        node[7] = currentTest.ear8;
      } else if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) {
        node[7][1] = mode;
      } else if (subId) {
        node[7] = [null, mode, null, null, null, [subId]];
      }
      patched = true;
    }

    if (node.length > 10 && Array.isArray(node[10]) && Array.isArray(node[10][0])) {
      node[10] = [cloneItems()];
      if (Array.isArray(node[2]) && Array.isArray(node[2][2]) && Array.isArray(node[2][2][8])) {
        node[2][2][8] = [cloneItems()];
      }
      if (currentTest.ear8) node[6] = currentTest.ear8;
      patched = true;
    }

    return patched;
  }

  function rewriteFreq(bodyStr) {
    if (typeof bodyStr !== "string" || !bodyStr.includes("f.req=") || !currentTest) return bodyStr;
    try {
      const parts = bodyStr.split("&");
      for (let i = 0; i < parts.length; i++) {
        if (!parts[i].startsWith("f.req=")) continue;

        const raw = decodeURIComponent(parts[i].slice(6).replace(/\+/g, " "));
        const outer = JSON.parse(raw);
        let bodyChanged = false;

        if (Array.isArray(outer)) {
          for (const group of outer) {
            if (!Array.isArray(group)) continue;
            for (const call of group) {
              if (!Array.isArray(call) || call[0] !== "Ngbm" || typeof call[1] !== "string") continue;

              let callChanged = false;          // reset per call — was leaking before
              const payload = JSON.parse(call[1]);
              if (Array.isArray(payload)) {
                if (patchNode(payload[0])) callChanged = true;
                if (patchNode(payload[1])) callChanged = true;
              }
              if (callChanged) {
                call[1] = JSON.stringify(payload);
                bodyChanged = true;
              }
            }
          }
        }

        if (bodyChanged) {
          parts[i] = "f.req=" + encodeURIComponent(JSON.stringify(outer));
          return parts.join("&");
        }
      }
    } catch (e) {}
    return bodyStr;
  }

  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (typeof body === "string" && body.indexOf("Ngbm") >= 0) body = rewriteFreq(body);
    } catch (e) {}
    return origSend.call(this, body);
  };

  function rewriteUrl(val) {
    const s = String(val || "");
    if (!currentTest || s.indexOf("/eacquire/multiline") < 0) return val;
    try {
      const u = new URL(s, location.origin);
      const earStr = u.searchParams.get("ear");
      if (!earStr) return val;

      const ear = JSON.parse(earStr);

      if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) {
        subId = ear[8][5][0];
      }
      if (Array.isArray(ear[13])) ear[13][0] = cloneItems();

      if (Array.isArray(ear[4]) && typeof ear[4][0] === "string") {
        try {
          const inner4 = JSON.parse(atob(ear[4][0]));
          if (Array.isArray(inner4) && inner4.length > 8) {
            inner4[8] = [cloneItems()];
            ear[4][0] = btoa(JSON.stringify(inner4));
          }
        } catch (e4) {}
      }

      const mode = (currentTest.ear8 && currentTest.ear8[1]) || 5;
      if (currentTest.ear8) {
        ear[8] = currentTest.ear8;
      } else if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) {
        ear[8][1] = mode;
      } else if (subId) {
        ear[8] = [null, mode, null, null, null, [subId]];
      }

      ear[24] = null;
      u.searchParams.set("ear", JSON.stringify(ear));
      return u.toString();
    } catch (e) {
      return val;
    }
  }

  // Trusted Types createScriptURL
  try {
    const ttp = window.TrustedTypePolicy && TrustedTypePolicy.prototype;
    if (ttp && typeof ttp.createScriptURL === "function") {
      const origCreate = ttp.createScriptURL;
      ttp.createScriptURL = function (input) {
        return origCreate.call(this, rewriteUrl(input));
      };
    }
  } catch (e) {}

  // iframe src property
  try {
    const srcDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "src");
    if (srcDesc && typeof srcDesc.set === "function") {
      Object.defineProperty(HTMLIFrameElement.prototype, "src", {
        configurable: srcDesc.configurable,
        enumerable: srcDesc.enumerable,
        get: srcDesc.get,
        set(v) {
          if (typeof v === "string") v = rewriteUrl(v);
          return srcDesc.set.call(this, v);
        }
      });
    }
  } catch (e) {}

  // setAttribute fallback
  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    try {
      if (this instanceof HTMLIFrameElement && String(name).toLowerCase() === "src") {
        val = rewriteUrl(String(val));
      }
    } catch (e) {}
    return origSetAttr.call(this, name, val);
  };

  /* ---------- config intake ---------- */
  function applyLayer(layer) {
    const cfg = makeCfg(layer);
    currentTest = cfg ? Object.assign({ layer: layer }, cfg) : null;
    subId = null;

    window.__GAPT_READY = true;
    window.__GAPT_STATE = { layer: layer || "off", mounted: !!currentTest };

    refreshBadge();
    try {
      window.postMessage({ __gapt: 1, type: "state", state: window.__GAPT_STATE }, "*");
    } catch (e) {}
  }

  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (!d || d.__gapt !== 1) return;

    if (d.type === "cfg") applyLayer(d.layer);
    if (d.type === "ping") {
      try {
        window.postMessage(
          { __gapt: 1, type: "state", state: window.__GAPT_STATE || { layer: "off", mounted: false } },
          "*"
        );
      } catch (e) {}
    }
  });

  // first read (content.js also posts one)
  let attrCfg = "off";
  try {
    attrCfg = document.documentElement.getAttribute("data-gapt-layer") || "off";
  } catch (e) {}
  applyLayer(attrCfg);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", refreshBadge, { once: true });
  } else {
    refreshBadge();
  }
})();