/* Xi · Google AI Pro Offer Injector — checkout overlay price guard
 * Reads the real terms inside the Play checkout iframe:
 * green bar = free trial, safe to continue. Red bar = you will be charged, stop.
 */
(() => {
  if (window.__GAPT_GUARD) return;
  try {
    if (window.top === window) return; // child frames only
  } catch (e) {}
  window.__GAPT_GUARD = true;

  const FREE_WORDS = [
    "free trial",
    "start your free trial",
    "$0.00",
    "0.00 today",
    "won't be charged",
    "no charge today",
    "you will not be charged"
  ];
  const PAID_WORDS = [
    "/mo after",
    "/month after",
    "per month after",
    "pay now",
    "charged today",
    "due today",
    "you will be charged"
  ];

  const STYLES = {
    ok: "linear-gradient(135deg,#3fe08c 0%,#00e2b8 100%)|#052018",
    bad: "linear-gradient(135deg,#ff7b7b 0%,#e53935 100%)|#ffffff",
    warn: "linear-gradient(135deg,#ffd166 0%,#ffa726 100%)|#231503"
  };

  let bar = null;

  function paint(kind, text) {
    if (!document.body) return;

    if (!bar) {
      bar = document.createElement("div");
      bar.setAttribute("role", "status");
      bar.setAttribute("aria-live", "assertive");
      bar.style.cssText =
        "position:fixed;left:0;right:0;top:0;z-index:2147483647;" +
        "padding:12px 16px;text-align:center;font-weight:600;" +
        "font:600 13px/1.45 Roboto,'Segoe UI',system-ui,sans-serif;letter-spacing:.2px;" +
        "box-shadow:0 2px 12px rgba(0,0,0,.45);";
      document.body.appendChild(bar);
    }

    const [bg, fg] = (STYLES[kind] || STYLES.warn).split("|");
    bar.style.background = bg;
    bar.style.color = fg;
    bar.textContent = text;
  }

  let pending = null;
  function schedule() {
    clearTimeout(pending);
    pending = setTimeout(judge, 180);
  }

  function judge() {
    let t = "";
    try {
      t = ((document.body && document.body.innerText) || "").toLowerCase();
    } catch (e) {
      return;
    }
    if (!t || t.length < 5) return;

    const free = FREE_WORDS.some((w) => t.indexOf(w) >= 0);
    const paid = PAID_WORDS.some((w) => t.indexOf(w) >= 0);

    if (free && !paid) {
      paint("ok", "Free trial detected — safe to subscribe (double-check the total says $0.00)");
    } else if (paid && !free) {
      paint("bad", "No free trial found — this looks like a real charge. Do not tap Subscribe; go back and retry another layer.");
    } else if (free && paid) {
      paint("warn", "Terms mention both free and paid — verify the amount manually before tapping Subscribe.");
    } else {
      paint("warn", "No price terms recognized yet (still loading).");
    }
  }

  setTimeout(judge, 1200);
  setTimeout(judge, 3000);
  setTimeout(judge, 6000);

  let mo = null;
  try {
    mo = new MutationObserver(schedule);
    const start = () => {
      if (!document.body) return;
      mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    };
    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start, { once: true });

    // stop watching once the sheet has settled
    setTimeout(() => {
      try { mo.disconnect(); } catch (e) {}
      judge();
    }, 20000);
  } catch (e) {}
})();