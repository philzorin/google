/* Target URL launcher for the extension popup.
 * Kept in an external file because Manifest V3 extension pages block inline scripts.
 */
(function () {
  'use strict';

  const input = document.getElementById('targetUrl');
  const button = document.getElementById('urlGo');

  if (!input || !button) return;

  function normalizeUrl(value) {
    let url = String(value || '').trim();
    if (!url) return null;

    if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }

    try {
      const parsed = new URL(url);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
      return parsed.href;
    } catch (_) {
      return null;
    }
  }

  function openInNewTab(url) {
    // Firefox exposes the promise-based `browser` namespace; Chrome exposes
    // the callback-based `chrome` namespace. Support both without opening twice.
    const extensionApi = globalThis.browser || globalThis.chrome;
    const tabsApi = extensionApi && extensionApi.tabs;

    if (tabsApi && typeof tabsApi.create === 'function') {
      try {
        if (globalThis.browser && extensionApi === globalThis.browser) {
          extensionApi.tabs.create({ url: url, active: true })
            .then(function () { window.close(); })
            .catch(function () { fallbackOpen(url); });
        } else {
          extensionApi.tabs.create({ url: url, active: true }, function () {
            const runtimeError = extensionApi.runtime && extensionApi.runtime.lastError;
            if (runtimeError) {
              fallbackOpen(url);
              return;
            }
            window.close();
          });
        }
        return;
      } catch (_) {
        // If the extension tabs API is unavailable in this host, use the
        // standard window fallback below.
      }
    }

    fallbackOpen(url);
  }

  function fallbackOpen(url) {
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
    if (newWindow) {
      window.close();
    }
  }

  function go() {
    const url = normalizeUrl(input.value);
    if (!url) {
      input.focus();
      return;
    }

    input.value = url;
    openInNewTab(url);
  }

  button.addEventListener('click', go);
  input.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      go();
    }
  });

  // Animate placeholder text (same behavior as the original popup).
  const placeholders = [
    'Enter target URL…',
    'one.google.com/plans',
    'tokenized.play.google.com'
  ];
  let placeholderIndex = 0;
  window.setInterval(function () {
    placeholderIndex = (placeholderIndex + 1) % placeholders.length;
    input.placeholder = placeholders[placeholderIndex];
  }, 3000);
})();
