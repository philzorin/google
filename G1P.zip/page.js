if (location.hostname === "one.google.com") {
(() => {
  if (window.__GAPT_HOOKED) return;
  window.__GAPT_HOOKED = true;

  const PREFIX = "subs:com.google.android.apps.subscriptions.red:";

  const TOKENS = {
    "12m": "AVbCH/cspB8VdqKJ+ax/uPxUFAVuYRPX4iSjtg4Fu0PG9zUeURSM7y//LlQva1dCd/rbKVM6EJmyiG/C9BoQ95pMl8yDCHuiwCvM5CuGJME=",
    "6m_ss": "AVbCH/cgl4zvPT2Lqw95Gn+RYAJIVwFwi783i6uVprX7u3MCa5J4CcTXH5RABa5WjBrUoQnwf8vI10TNV7ktd26myIdxqIwGmNoJ5ofYNqpQ10RKoSvHs75wsfA=",
    "6m": "AVbCH/fUON3w8hpfeutprA3BMQwrBwYIB6Y8CSWi1isDCDswKUUhGQ3dluj5WXsNKOvr8K5UULBGrRsf4KlW1rHLz0fF3SvxQhBFRbBOHCA=",
    "6m_2": "AVbCH/cJ5SeHgkVRt+bdcrapx/aLSu2kbsBgMdI413zbllDNsNQoC/zVlG/Npbu55WlMzBwWPhUedIvZFDg7fw0CmCv/8DKj04IZ21pK7mrV/hh5",
    "ultra20tb_12m": "AYrTWi65Jbm3KRubLXLLA3Re29zKibSnRbvAJEPfxEIVs/d57w8vEhsU7hSkSAfGyjZH8B7/5aj5UTlidbsEwUH8aPN2RTA6pKiltA==",
    "ultra20tb_6m": "AYrTWi6lMoHTB2cVb1VC+i3DHvfp1Q9VGblBeF9b1+O8e5+kNws87YdcgNEUJOuHJDp/mitKx1KmBCYurbXIubpM50o4AqgcBB3gMGk85mQ=",
    "ultra20tb_3m": "AYrTWi6sldhCH+REVXA3inXWB+LuAvtnSPYHMvhbqKmv3TRdQPhoynS4ZTLxPEiaNGnaAmDTqliYzrLwJ3Aq49Vi9ktjNP+xcTF5R9Yn1MQ=",
    "ultra20tb_1m": "AYrTWi5QWD5gc0ZxMJHAAUvXbYRFJgI6w5vnF9PKIFg1DFQML36iijrmN5Vum7u9ty2JnHvt9JFLgsfGKwScJcfZaKttqn0hSX4Fnpdn9No=",
    "ultra30tb_12m": "AYrTWi51Eo3HG0tq1J6SYr4u3FDCCxb6xSEEWHskaFwSA7Vn4y+Lfqlfy+Lbkx2T/xPi4uCRB71ZIn+weD0kHZsMgS6ogUiZ8hG9SA==",
    "ultra30tb_6m": "AYrTWi5hXUkLGa1e7nBstxl4Z3cUcYWzHF38Xks304ClJj8yVxeFCwDg/pJg82w8w9xHsk8Wl5WNhYKk26LB9besC0kYJ6AvlXapJA==",
    "ultra30tb_3m": "AYrTWi4iJ8AzqZkDL53g/dcS7g93mZgiEBJANI0lOucBiUITWEYqCiwLsIXY7P62rmMWb+wFR4WW9tQlFrskR67oCzzwVHghPSs29w==",
    "ultra30tb_1m": "AYrTWi7nBQ2Zn0z4s+QJOwg9kQRwH3+z+HXpzRqw9IIU4/C48vPvjH32Bub8SHrWq3YX+yI4g1wJgviYiLCobJNqc9DqRd9WZnDdaQ=="
  };
  const SKUS = {
    "ultra20tb_12m": "g1.play.20tb",
    "ultra20tb_6m": "g1.play.20tb",
    "ultra20tb_3m": "g1.play.20tb",
    "ultra20tb_1m": "g1.play.20tb",
    "ultra30tb_12m": "g1.play.ai.pro",
    "ultra30tb_6m": "g1.play.ai.pro",
    "ultra30tb_3m": "g1.play.ai.pro",
    "ultra30tb_1m": "g1.play.ai.pro"
  };
  const YT_FREE_TOK = "AVbCH/eW4Nfp8KBl0zlm7x9PhaiCvpnqwUuL2D8NFPBQgmM9+HuYS1h2xH5lLWU/BsBj775LK5GqK8UHKqoSzhDDz+PqP3paNesqLU0r9i6XCrYa";

  const clone = (v) => JSON.parse(JSON.stringify(v));

  let currentTest = null;
  let subId = null;

  function makeCfg(layer) {
    if (!layer || layer === "off" || !TOKENS[layer]) return null;
    const sku = SKUS[layer] || "g1.2tb.ai.subs_variant";
    const items = [
      [[PREFIX + sku, 21], null, null, null, 1, [TOKENS[layer]]]
    ];
    // Ultra layers carry only their own SKU, exactly as in GeminiTool.
    // The YouTube add-on stays on the regular layers only.
    if (!SKUS[layer]) {
      items.push([[PREFIX + "g1.youtube_premium_individual_add_on", 21], null, null, null, 1, [YT_FREE_TOK]]);
    }
    return {
      name: "gapt_" + layer,
      full_items: items,
      ear8: null
    };
  }

  let badge = null;
  let checkoutSeenAt = 0;
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://tokenized.play.google.com" || !event.data) return;
    if (event.data.type === "gapt-checkout-closed") {
      checkoutSeenAt = 0;
      if (badge) badge.style.display = "";
    } else if (event.data.type === "gapt-checkout-visible") {
      checkoutSeenAt = Date.now();
      if (badge) badge.style.display = "none";
    }
  });
  setInterval(() => {
    if (badge) badge.style.display = Date.now() - checkoutSeenAt < 1200 ? "none" : "";
  }, 100);
  function showBadge(text) {
    try {
      if (!document.body) return;
      if (!badge) {
        badge = document.createElement("div");
        badge.style.cssText = "position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:2147483647;" +
          "padding:11px 15px;border-radius:12px;font:600 12px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;" +
          "box-shadow:0 8px 24px rgba(0,0,0,.22);border:1px solid #2f6b63;background:#0c2529;color:#d5f2ee;max-width:300px;";
        document.body.appendChild(badge);
      }
      badge.style.display = Date.now() - checkoutSeenAt < 1200 ? "none" : "";
      badge.textContent = text;
      badge.style.background = currentTest ? "#0d2b25" : "#0c2529";
      badge.style.borderColor = currentTest ? "#2f7a63" : "#2f6b63";
      badge.style.color = currentTest ? "#a7ecd4" : "#d5f2ee";
    } catch (e) {}
  }

  function refreshBadge() {
    if (!currentTest) {
      showBadge("Injector: Disabled");
    } else {
      const label = { "12m": "12 months", "6m_ss": "6 months (Samsung)", "6m": "6 months (Pixel)", "6m_2": "6 months (backup)", "ultra20tb_12m": "Ultra 20TB · 12M", "ultra20tb_6m": "Ultra 20TB · 6M", "ultra20tb_3m": "Ultra 20TB · 3M", "ultra20tb_1m": "Ultra 20TB · 1M", "ultra30tb_12m": "Ultra 30TB · 12M", "ultra30tb_6m": "Ultra 30TB · 6M", "ultra30tb_3m": "Ultra 30TB · 3M", "ultra30tb_1m": "Ultra 30TB · 1M" }[currentTest.layer] || currentTest.layer;
      showBadge("Active · " + label + (subId ? " · Renewal stack" : ""));
    }
  }

  function patchNode(node) {
    if (!Array.isArray(node) || !currentTest || !Array.isArray(currentTest.full_items)) return false;
    const items = clone(currentTest.full_items);
    let patched = false;
    if (node.length > 12 && Array.isArray(node[12])) {
      if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) subId = node[7][5][0];
      node[12] = items;
      const mode = (currentTest.ear8 && currentTest.ear8[1]) || 5;
      if (currentTest.ear8) node[7] = clone(currentTest.ear8);
      else if (Array.isArray(node[7]) && Array.isArray(node[7][5]) && node[7][5].length > 0) node[7][1] = mode;
      else if (subId) node[7] = [null, mode, null, null, null, [subId]];
      patched = true;
    }
    if (node.length > 10 && Array.isArray(node[10]) && Array.isArray(node[10][0])) {
      node[10] = [items];
      if (Array.isArray(node[2]) && Array.isArray(node[2][2]) && Array.isArray(node[2][2][8])) {
        node[2][2][8] = [items];
      }
      if (currentTest.ear8) node[6] = clone(currentTest.ear8);
      patched = true;
    }
    return patched;
  }

  function rewriteFreq(bodyStr) {
    if (typeof bodyStr !== "string" || !bodyStr.includes("f.req=") || !currentTest) return bodyStr;
    try {
      const parts = bodyStr.split("&");
      for (let i = 0; i < parts.length; i++) {
        if (parts[i].startsWith("f.req=")) {
          const raw = decodeURIComponent(parts[i].slice(6).replace(/\+/g, " "));
          const outer = JSON.parse(raw);
          let changed = false;
          if (Array.isArray(outer)) {
            for (const group of outer) {
              if (!Array.isArray(group)) continue;
              for (const call of group) {
                if (Array.isArray(call) && call[0] === "Ngbm" && typeof call[1] === "string") {
                  const payload = JSON.parse(call[1]);
                  if (Array.isArray(payload)) {
                    if (patchNode(payload[0])) changed = true;
                    if (patchNode(payload[1])) changed = true;
                  }
                  if (changed) call[1] = JSON.stringify(payload);
                }
              }
            }
          }
          if (changed) {
            parts[i] = "f.req=" + encodeURIComponent(JSON.stringify(outer));
            return parts.join("&");
          }
        }
      }
    } catch (e) {}
    return bodyStr;
  }

  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (typeof body === "string" && body.includes("Ngbm")) body = rewriteFreq(body);
    } catch (e) {}
    return origSend.call(this, body);
  };

  function rewriteUrl(val) {
    const s = String(val || "");
    if (!s.includes("/eacquire/multiline") || !currentTest || !Array.isArray(currentTest.full_items)) return val;
    try {
      const u = new URL(s, location.origin);
      const earStr = u.searchParams.get("ear");
      if (!earStr) return val;
      const ear = JSON.parse(earStr);
      const items = clone(currentTest.full_items);
      if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) subId = ear[8][5][0];
      if (Array.isArray(ear[13])) ear[13][0] = items;
      if (Array.isArray(ear[4]) && typeof ear[4][0] === "string") {
        try {
          const inner4 = JSON.parse(atob(ear[4][0]));
          if (Array.isArray(inner4) && inner4.length > 8) {
            inner4[8] = [items];
            ear[4][0] = btoa(JSON.stringify(inner4));
          }
        } catch (e4) {}
      }
      const mode = (currentTest.ear8 && currentTest.ear8[1]) || 5;
      if (currentTest.ear8) ear[8] = clone(currentTest.ear8);
      else if (Array.isArray(ear[8]) && Array.isArray(ear[8][5]) && ear[8][5].length > 0) ear[8][1] = mode;
      else if (subId) ear[8] = [null, mode, null, null, null, [subId]];
      ear[24] = null;
      u.searchParams.set("ear", JSON.stringify(ear));
      return u.toString();
    } catch (e) {
      return val;
    }
  }

  if (window.TrustedTypePolicy && TrustedTypePolicy.prototype.createScriptURL) {
    const origCreate = TrustedTypePolicy.prototype.createScriptURL;
    TrustedTypePolicy.prototype.createScriptURL = function (input, ...args) {
      return origCreate.call(this, rewriteUrl(input), ...args);
    };
  }

  const srcDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "src");
  if (srcDesc && srcDesc.set) {
    Object.defineProperty(HTMLIFrameElement.prototype, "src", {
      ...srcDesc,
      set(v) {
        if (typeof v === "string") v = rewriteUrl(v);
        return srcDesc.set.call(this, v);
      }
    });
  }
  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    if (this instanceof HTMLIFrameElement && String(name).toLowerCase() === "src") val = rewriteUrl(String(val));
    return origSetAttr.call(this, name, val);
  };

  function applyLayer(layer) {
    const cfg = makeCfg(layer);
    currentTest = cfg ? Object.assign({ layer: layer }, cfg) : null;
    window.__GAPT_READY = true;
    window.__GAPT_STATE = { layer: layer || "off", mounted: !!currentTest };
    refreshBadge();
    try {
      window.postMessage({ __gapt: 1, type: "state", state: window.__GAPT_STATE }, "*");
    } catch (e) {}
  }

  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (!d || d.__gapt !== 1) return;
    if (d.type === "cfg") applyLayer(d.layer);
    if (d.type === "ping") {
      try {
        window.postMessage({ __gapt: 1, type: "state", state: window.__GAPT_STATE || { layer: "off", mounted: false } }, "*");
      } catch (e) {}
    }
  });
  const attrCfg = document.documentElement.getAttribute("data-gapt-layer");
  applyLayer(attrCfg || "off");
  document.addEventListener("DOMContentLoaded", refreshBadge);
})();

}
if (location.hostname === "tokenized.play.google.com") {
(() => {
  if (window.__GAPT_GUARD || window.top === window) return;
  window.__GAPT_GUARD = true;
  const FREE_WORDS = ["free trial", "start your free trial", "\u514d\u8d39\u8bd5\u7528", "US$0.00", "$0.00", "0,00", "\u20ac0.00", "won't be charged", "\u4e0d\u4f1a\u5411\u60a8\u6536\u8d39", "\u4e0d\u4f1a\u6536\u8d39"];
  const PAID_WORDS = ["/mo after", "/month after", "per month after", "\u7acb\u5373\u4ed8\u6b3e", "pay now", "\u4eca\u65e5\u6263\u6b3e", "charged today"];

  let bar = null;
  function signalVisible() {
    if (bar && document.contains(bar)) {
      window.top.postMessage({ type: "gapt-checkout-visible" }, "https://one.google.com");
    }
  }
  setInterval(signalVisible, 400);
  function signalClosed() {
    window.top.postMessage({ type: "gapt-checkout-closed" }, "https://one.google.com");
  }
  window.addEventListener("pagehide", signalClosed);
  function paint(kind, text) {
    if (!document.body) return;
    if (!bar) {
      bar = document.createElement("div");
      bar.style.cssText = "position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:2147483647;" +
        "width:max-content;max-width:calc(100% - 32px);box-sizing:border-box;padding:11px 15px;border:1px solid;border-radius:12px;" +
        "box-shadow:0 8px 24px rgba(0,0,0,.22);font:600 12px/1.5 -apple-system,Segoe UI,Roboto,'Microsoft YaHei',sans-serif;text-align:center;";
      document.body.appendChild(bar);
    }
    bar.style.background = kind === "ok" ? "#0d2b25" : (kind === "bad" ? "#2c1a20" : "#26221a");
    bar.style.borderColor = kind === "ok" ? "#2f7a63" : (kind === "bad" ? "#8d4a58" : "#7c6539");
    bar.style.color = kind === "ok" ? "#a7ecd4" : (kind === "bad" ? "#ffd1d7" : "#f3dbab");
    if (bar.textContent !== text) bar.textContent = text;
    signalVisible();
  }

  function judge() {
    let t = "";
    try {
      t = (document.body && document.body.innerText || "");
      if (bar) t = t.replace(bar.innerText, "");
      t = t.toLowerCase();
    } catch (e) {
      return;
    }
    if (!t || t.trim().length < 5) {
      if (bar) { bar.remove(); bar = null; signalClosed(); }
      return;
    }
    const free = FREE_WORDS.some((w) => t.includes(w.toLowerCase()));
    const paid = PAID_WORDS.some((w) => t.includes(w.toLowerCase()));

    if (free && !paid) {
      paint("ok", "✅ Free trial detected. Confirm $0.00 total.");
    } else if (paid && !free) {
      paint("bad", "❌ No free trial. Charges may apply.");
    } else if (free && paid) {
      paint("warn", "⚠️ Trial terms detected. Check total and renewal price.");
    } else {
      paint("warn", "⏳ Checking checkout terms…");
    }
  }
  let pending = null;
  function scheduleJudge() {
    if (pending !== null) return;
    pending = setTimeout(() => { pending = null; judge(); }, 100);
  }
  function start() {
    if (!document.body) return;
    judge();
    try {
      const mo = new MutationObserver((changes) => {
        if (changes.some((change) => !bar || (change.target !== bar && !bar.contains(change.target)))) scheduleJudge();
      });
      mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    } catch (e) {}
    setTimeout(judge, 1000);
    setTimeout(judge, 3000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();

}