const IS_EXTENSION_PAGE = /^(chrome-extension|moz-extension|safari-web-extension|safari-extension|ms-browser-extension|file):$/.test(location.protocol);

if (IS_EXTENSION_PAGE) {
const LABELS = { off: "Disabled", "12m": "12 months", "6m_ss": "6 months (Samsung)", "6m": "6 months (Pixel)", "6m_2": "6 months (backup)", "ultra20tb_12m": "Ultra 20TB · 12M", "ultra20tb_6m": "Ultra 20TB · 6M", "ultra20tb_3m": "Ultra 20TB · 3M", "ultra20tb_1m": "Ultra 20TB · 1M", "ultra30tb_12m": "Ultra 30TB · 12M", "ultra30tb_6m": "Ultra 30TB · 6M", "ultra30tb_3m": "Ultra 30TB · 3M", "ultra30tb_1m": "Ultra 30TB · 1M" };
const stateEl = document.getElementById("state");

function radios() {
  return document.querySelectorAll('input[name="layer"]');
}

function paintState(st) {
  if (!stateEl) return;
  const layer = (st && st.layer) || "off";
  const mounted = !!(st && st.mounted) && layer !== "off";
  stateEl.className = mounted ? "ok" : "warn";
  stateEl.textContent = mounted
    ? "Active · " + (LABELS[layer] || layer)
    : "No active injection detected — open one.google.com/plans and refresh.";
}

function queryTab() {
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = tabs && tabs[0];
      if (!t) return paintState(null);
      chrome.tabs.sendMessage(t.id, { type: "getState" }, (resp) => {
        if (chrome.runtime.lastError || !resp) return paintState(null);
        paintState(resp);
      });
    });
  } catch (e) {
    paintState(null);
  }
}

function isGoogleOne(tab) {
  return !!(tab && tab.url && /^https:\/\/one\.google\.com\//.test(tab.url));
}

function pickTab(tabs) {
  const list = Array.isArray(tabs) ? tabs : [];
  return list.filter(isGoogleOne)[0] || list[0] || null;
}

// Firefox resolves "currentWindow" differently for a popup hosted in a
// browser sheet, so walk through the other queries before giving up.
function withTargetTab(cb) {
  const attempts = [
    { active: true, currentWindow: true },
    { active: true, lastFocusedWindow: true },
    { active: true }
  ];
  let i = 0;
  const next = () => {
    if (i >= attempts.length) return cb(null);
    const opts = attempts[i++];
    try {
      chrome.tabs.query(opts, (tabs) => {
        void chrome.runtime.lastError;
        const t = pickTab(tabs);
        if (t) return cb(t);
        next();
      });
    } catch (e) {
      next();
    }
  };
  next();
}

function syncRadios(layer) {
  const want = layer || "off";
  radios().forEach((el) => { el.checked = el.value === want; });
}

function applySelection(el) {
  const layer = el.value;
  // Persist first — this has to survive the popup closing in any browser.
  try {
    chrome.storage.local.set({ gapt_layer: layer }, () => { void chrome.runtime.lastError; });
  } catch (e) {}
  withTargetTab((t) => {
    if (!t) return;
    try {
      chrome.tabs.sendMessage(t.id, { type: "setLayer", layer: layer }, () => { void chrome.runtime.lastError; });
    } catch (e) {}
  });
  setTimeout(queryTab, 350);
}

function bind() {
  radios().forEach((el) => {
    el.addEventListener("change", () => {
      if (!el.checked) return;
      applySelection(el);
    });
  });
}

function init(layer) {
  syncRadios(layer);
  bind();
  queryTab();
  setTimeout(queryTab, 800);
}

try {
  chrome.storage.local.get(["gapt_layer"], (r) => init((r && r.gapt_layer) || "off"));
} catch (e) {
  init("off");
}

try {
  chrome.storage.onChanged.addListener((ch) => {
    if (ch && ch.gapt_layer) syncRadios(ch.gapt_layer.newValue || "off");
  });
} catch (e) {}

setInterval(queryTab, 1500);

} else {
(() => {
  let lastState = { layer: "off", mounted: false };

  function push(layer) {
    try {
      document.documentElement.setAttribute("data-gapt-layer", layer || "off");
    } catch (e) {}
    window.postMessage({ __gapt: 1, type: "cfg", layer: layer || "off" }, "*");
  }

  function loadAndPush() {
    try {
      chrome.storage.local.get(["gapt_layer"], (r) => push(r && r.gapt_layer ? r.gapt_layer : "off"));
    } catch (e) {
      push("off");
    }
  }
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (d && d.__gapt === 1 && d.type === "state" && d.state) lastState = d.state;
  });
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) return;
      if (msg.type === "getState") {
        window.postMessage({ __gapt: 1, type: "ping" }, "*");
        setTimeout(() => sendResponse(lastState), 150);
        return true;
      }
      if (msg.type === "setLayer") {
        push(msg.layer);
        setTimeout(() => sendResponse({ ok: true, state: lastState }), 150);
        return true;
      }
    });
    chrome.storage.onChanged.addListener((ch) => {
      if (ch && ch.gapt_layer) push(ch.gapt_layer.newValue || "off");
    });
  } catch (e) {}

  loadAndPush();
  setTimeout(loadAndPush, 800);
  setTimeout(loadAndPush, 2500);
})();

}